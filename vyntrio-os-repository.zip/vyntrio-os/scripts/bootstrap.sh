#!/usr/bin/env bash
set -euo pipefail
echo "Bootstrap Vyntrio OS development environment"
