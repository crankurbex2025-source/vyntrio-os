# Vyntrio OS

Vyntrio OS ist ein kommerzielles Linux-basiertes Home-Server- und Private-Cloud-Betriebssystem. Dieses Repository enthält die technische Produktdokumentation, Architekturgrundlagen, Entwicklungsstruktur für Cursor, eine Start-Repository-Struktur und Prompt-Vorlagen für alle Entwicklungsphasen.

## Repository-Übersicht
- `docs/` vollständige Produkt- und Technikdokumentation
- `cursor-prompts/` Prompt-Vorlagen je Phase
- `.github/workflows/` CI/CD-Startpunkt
- `scripts/` Build-, Test- und Packaging-Skripte
- `ops/` Deploy-, PKI- und Release-Artefakte

## Startprinzipien
- Erst Dokumentation lesen
- Modular entwickeln
- Produktionsqualität liefern
- Tests und Sicherheit als Release-Bedingung behandeln
