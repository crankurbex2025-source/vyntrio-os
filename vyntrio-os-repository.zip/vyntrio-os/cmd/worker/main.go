package main

import "fmt"

func main() {
	fmt.Println("vyntrio worker bootstrap")
}
