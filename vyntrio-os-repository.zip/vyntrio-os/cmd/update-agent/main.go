package main

import "fmt"

func main() {
	fmt.Println("vyntrio update-agent bootstrap")
}
