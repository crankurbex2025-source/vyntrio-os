package main

import "fmt"

func main() {
	fmt.Println("vyntrio api bootstrap")
}
