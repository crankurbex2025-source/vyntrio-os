# Cursor Repo Setup

## Ziel
Dieses Repository ist so vorbereitet, dass es direkt auf GitHub hochgeladen und danach per Git/SSH von Cursor geklont werden kann.

## GitHub Ablauf
1. Neues leeres Repository auf GitHub anlegen, z. B. `vyntrio-os`.
2. Lokales Repository initialisieren.
3. Dateien committen.
4. SSH-Remote setzen.
5. Push auf `main`.

## Befehle
```bash
git init
git branch -M main
git add .
git commit -m "Initial Vyntrio OS repository foundation"
git remote add origin git@github.com:YOUR-ORG-OR-USER/vyntrio-os.git
git push -u origin main
```

## Cursor via SSH
In Cursor oder auf dem Zielserver:
```bash
git clone git@github.com:YOUR-ORG-OR-USER/vyntrio-os.git
cd vyntrio-os
```

## Pflicht vor produktiver Entwicklung
- GitHub SSH Key testen
- Branch Protection aktivieren
- Secrets niemals committen
- Vor großen Umbauten Snapshot/Tag erzeugen
- Änderungen zuerst in dokumentierten Phasen umsetzen
