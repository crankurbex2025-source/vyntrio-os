# GitHub Repository Structure

```text
vyntrio-os/
├── .github/
│   └── workflows/
│       ├── ci.yml
│       ├── release.yml
│       └── security.yml
├── cmd/
│   ├── api/
│   ├── worker/
│   ├── installer/
│   └── update-agent/
├── internal/
│   ├── domain/
│   ├── application/
│   ├── infrastructure/
│   └── interfaces/
├── frontend/
│   ├── app/
│   ├── src/
│   └── public/
├── packages/
│   ├── ui/
│   ├── sdk/
│   └── config/
├── build/
├── distro/
├── docs/
├── cursor-prompts/
├── scripts/
├── ops/
├── tests/
│   ├── integration/
│   ├── e2e/
│   └── fixtures/
└── Makefile
```
