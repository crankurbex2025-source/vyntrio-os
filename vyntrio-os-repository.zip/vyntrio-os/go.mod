module github.com/vyntrio/vyntrio-os

go 1.24
